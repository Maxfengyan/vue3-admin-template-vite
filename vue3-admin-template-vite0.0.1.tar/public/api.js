(function () {
  window.api = {
    epgms:
      "http://10.10.8.14:9999/mock/5f23d33facd7311a719430ed/epgms",
    others:
      "http://10.10.8.14:9999/mock/5f23d3f0acd7311a719430f2/boss",
  };
})();
