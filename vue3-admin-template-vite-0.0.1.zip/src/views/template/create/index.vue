<template>
  <h1>template/create</h1>
</template>

<script>
export default {};
</script>

<style>
</style>